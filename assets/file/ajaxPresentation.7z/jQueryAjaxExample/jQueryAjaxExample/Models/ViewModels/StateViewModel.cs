﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jQueryAjaxExample.Models.ViewModels
{
    public class StateViewModel
    {

        public string SelectedState { get; set; }
        public List<jQueryAjaxExample.Models.Core.State> StateList { get; set; }

    }
}