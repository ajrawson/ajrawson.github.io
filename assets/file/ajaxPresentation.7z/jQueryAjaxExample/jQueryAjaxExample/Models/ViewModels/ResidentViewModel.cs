﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jQueryAjaxExample.Models.Core;

namespace jQueryAjaxExample.Models.ViewModels
{
    public class ResidentViewModel
    {

        public int ID { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Occupation { get; set; }
        public string State { get; set; }

        public List<Resident> Residents { get; set; }
        public List<String> States { get; set; }

    }
}