﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using jQueryAjaxExample.Models.Core;

namespace jQueryAjaxExample.Models.Data
{
    public class AjaxContext : DbContext
    {

        public AjaxContext() : base("AjaxExample") { }

        public DbSet<State> States { get; set; }
        public DbSet<Resident> Residents { get; set; }

    }
}