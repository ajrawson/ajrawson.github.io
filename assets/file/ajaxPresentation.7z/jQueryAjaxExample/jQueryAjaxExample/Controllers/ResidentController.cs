﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using jQueryAjaxExample.Models.Core;
using jQueryAjaxExample.Models.ViewModels;
using jQueryAjaxExample.Models.Data;

namespace jQueryAjaxExample.Controllers
{
    public class ResidentController : Controller
    {

        public ActionResult Index()
        {
            using (var context = new AjaxContext())
            {

                var viewModel = new ResidentViewModel();
                viewModel.Residents = (from c in context.Residents.Include("State")
                                       orderby c.LastName
                                       select c).ToList();

                viewModel.States = (from c in context.States
                                    orderby c.Name
                                    select c.Name).ToList();

                viewModel.States.Insert(0, string.Empty);

                return View(viewModel);

            }
        }

        public JsonResult GetResident(int ID)
        {

            using (var context = new AjaxContext())
            {

                var res = (from c in context.Residents
                           where c.ID == ID
                           select new ResidentViewModel { ID = c.ID, 
                               FirstName = c.FirstName, 
                               MiddleName = c.MiddleName, 
                               LastName = c.LastName, 
                               Occupation = c.Occupation, 
                               State = c.State.Name }).FirstOrDefault();

                return Json(res, JsonRequestBehavior.AllowGet);

            }

        }

        [HttpPost]
        public ActionResult EditResident(ResidentViewModel res)
        {

            using (var context = new AjaxContext())
            {
                Resident newRes;

                if (res.ID == 0)
                {
                    newRes = new Resident();
                }
                else
                {
                    newRes = (from c in context.Residents
                              where c.ID == res.ID
                              select c).FirstOrDefault();
                }

                newRes.FirstName = res.FirstName;
                newRes.MiddleName = res.MiddleName;
                newRes.LastName = res.LastName;
                newRes.Occupation = res.Occupation;
                newRes.StateID = (from c in context.States
                                  where c.Name == res.State
                                  select c.ID).FirstOrDefault();

                if (res.ID == 0)
                {
                    context.Residents.Add(newRes);
                }

                context.SaveChanges();

                var resList = (from c in context.Residents
                               orderby c.LastName
                               select new ResidentViewModel { ID = c.ID, 
                                   FirstName = c.FirstName, 
                                   MiddleName = c.MiddleName, 
                                   LastName = c.LastName, 
                                   Occupation = c.Occupation, 
                                   State = c.State.Name }).ToList();

                return Json(resList, JsonRequestBehavior.AllowGet);
                
            }

        }

    }
}
