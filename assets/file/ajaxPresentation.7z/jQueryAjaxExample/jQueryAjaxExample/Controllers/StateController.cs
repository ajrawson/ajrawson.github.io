﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using jQueryAjaxExample.Models.Core;
using jQueryAjaxExample.Models.Data;
using jQueryAjaxExample.Models.ViewModels;

namespace jQueryAjaxExample.Controllers
{
    public class StateController : Controller
    {

        public ActionResult Index()
        {

            using (var context = new AjaxContext())
            {

                var viewModel = new jQueryAjaxExample.Models.ViewModels.StateViewModel();
                viewModel.StateList = context.States.OrderBy(o => o.Name).ToList();
                viewModel.StateList.Insert(0, new State { ID = -99, Name = string.Empty, Abbreviation = "XX" });

                return View(viewModel);

            }

        }

        public ActionResult ShowState(int ID)
        {

            using (var context = new AjaxContext())
            {

                var state = (from c in context.States
                             where c.ID == ID
                             select c).FirstOrDefault();

                return PartialView("_StateShowDetails", state);

            }

        }

        public ActionResult EditState(int ID)
        {

            using (var context = new AjaxContext())
            {

                var state = (from c in context.States
                             where c.ID == ID
                             select c).FirstOrDefault();

                return PartialView("_StateEditDetails", state);

            }

        }

        [HttpPost]
        public ActionResult EditState(State state)
        {

            using (var context = new AjaxContext())
            {

                var oldState = (from c in context.States
                                where c.ID == state.ID
                                select c).FirstOrDefault();

                oldState.StateBird = state.StateBird;
                oldState.Description = state.Description;

                context.SaveChanges();

                return PartialView("_StateShowDetails", oldState);

            }

        }

        public ActionResult GetResidents(int ID)
        {

            using (var context = new AjaxContext())
            {

                var residents = (from c in context.Residents
                                 where c.StateID == ID
                                 orderby c.LastName
                                 select new ResidentViewModel { ID = c.ID, 
                                     FirstName = c.FirstName, 
                                     MiddleName = c.MiddleName, 
                                     LastName = c.LastName, 
                                     Occupation = c.Occupation, 
                                     State = c.State.Name }).ToList();

                return Json(residents, JsonRequestBehavior.AllowGet);

            }

        }

    }
}
