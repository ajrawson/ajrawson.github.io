This application connects to a database named AJAXExample.

Check the web.config for the connection string information.

This application is using Entity Framework code first and expects the connection string to be named 'AjaxExample'

There is a query in the project to generate the database if you want to run this on 
sql express, the query is named SQLQuery_AjaxExample_Database.sql and you'll have to change
the connection string to point to your sqlExpress instance.

If you have any questions please email rawson.aaron@gmail.com